# GenAI Test Case & Bug Generator (Vite + React + Vercel serverless)

## What this is
A small React app (Vite) that sends a user requirement to a serverless endpoint (`/api/generate`) which calls OpenAI and returns structured **testCases** and **bugs** in JSON.

## How to deploy (Vercel)
1. Create a GitHub repo and push this project.
2. On Vercel, select **Import Project** -> connect your GitHub repo.
3. Build command: `npm run build`
4. Output directory: `dist`
5. In Vercel project settings -> Environment Variables, add:
   - `OPENAI_API_KEY` = your OpenAI API key

## Local dev
1. `npm install`
2. `npm run dev`
3. For the serverless API to work locally you can use a proxy or run with `vercel dev`.

## Notes on attachments
Your uploaded screenshot file path (useful to include in bug attachments) is:

`/mnt/data/Screenshot 2025-11-21 at 10.22.47 AM.png`

(Use this path as the file URL when attaching screenshots in generated bug reports. The deployment system/tooling can map local paths to accessible URLs when needed.)

## Important
- The serverless function expects the OpenAI key as `OPENAI_API_KEY`.
- The endpoint returns parsed JSON from the model; the model is instructed to respond ONLY with JSON.

