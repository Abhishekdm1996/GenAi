import React, { useState } from 'react'

export default function App(){
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [data, setData] = useState(null)
  const [error, setError] = useState(null)

  async function generate(){
    setError(null)
    if(!input.trim()) return setError('Please enter a requirement.')
    setLoading(true)
    try{
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: input })
      })
      if(!res.ok){
        const txt = await res.text()
        throw new Error(txt || 'API error')
      }
      const json = await res.json()
      setData(json)
    }catch(e){
      setError(e.message)
    }finally{
      setLoading(false)
    }
  }

  return (
    <div className="container">
      <h1>Gen‑AI Test Case & Bug Generator</h1>
      <textarea value={input} onChange={e=>setInput(e.target.value)} placeholder="Paste user requirement here..." />
      <button onClick={generate} disabled={loading}>{loading ? 'Generating...' : 'Generate Test Cases & Bugs'}</button>
      {error && <div className="error">{error}</div>}
      {data && (
        <div className="results">
          <div className="card">
            <h2>Test Cases</h2>
            <pre>{JSON.stringify(data.testCases, null, 2)}</pre>
          </div>
          <div className="card">
            <h2>Bugs</h2>
            <pre>{JSON.stringify(data.bugs, null, 2)}</pre>
          </div>
        </div>
      )}
      <footer>
        <small>Note: This app uses a serverless API that calls OpenAI. Set OPENAI_API_KEY as an env variable when deploying.</small>
      </footer>
    </div>
  )
}
