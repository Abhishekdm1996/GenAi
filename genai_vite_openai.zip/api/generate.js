/**
 * Vercel Serverless Function (api/generate.js)
 * Expects env var OPENAI_API_KEY to be set (during deployment).
 * This endpoint forwards the prompt to OpenAI's Chat Completions API and formats responses.
 */

import fetch from 'node-fetch'

export default async function handler(req, res){
  if(req.method !== 'POST') return res.status(405).send('Method Not Allowed')
  const body = req.body || {}
  const prompt = body.prompt || ''
  if(!prompt) return res.status(400).json({ error: 'Prompt is required' })

  const key = process.env.OPENAI_API_KEY
  if(!key) return res.status(500).json({ error: 'OPENAI_API_KEY not set in environment' })

  // Build a system + user prompt instructing model to output JSON
  const system = `You are a helpful assistant that generates structured test cases and bug reports.
Return a JSON object with keys: testCases (array) and bugs (array).
Test case object fields: tcNo, stepNo, steps, actual, expected, status, result.
Bug object fields: bugId, title, description, steps, actual, expected, attachments, environment.

Respond ONLY with valid JSON.`
  const user = `Requirement:\n${prompt}\n\nProduce 3 test cases and up to 3 bugs with clear steps.`

  try{
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method:'POST',
      headers: {
        'Content-Type':'application/json',
        'Authorization': 'Bearer ' + key
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini', // change if needed
        messages: [
          { role: 'system', content: system },
          { role: 'user', content: user }
        ],
        temperature: 0.2,
        max_tokens: 900
      })
    })
    const j = await response.json()
    // Extract assistant content
    const text = j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content
    if(!text) return res.status(500).json({ error: 'No content from OpenAI', raw: j })
    // Try to parse JSON from model output
    let parsed = null
    try{
      parsed = JSON.parse(text)
    }catch(e){
      // attempt to extract JSON substring
      const m = text.match(/\{[\s\S]*\}/)
      if(m) parsed = JSON.parse(m[0])
      else return res.status(500).json({ error: 'Failed to parse model output as JSON', rawText: text })
    }
    return res.status(200).json(parsed)
  }catch(err){
    return res.status(500).json({ error: err.message })
  }
}
